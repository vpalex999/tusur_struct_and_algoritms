﻿// dejkstra.cpp
// Используя алгоритм Дейкстры, найти длины кратчайших путей во
// взвешенном ориентированном графе от заданной вершины до всех остальных.
// Граф задать в текстовом файле матрицей весов.

#include "pch.h"
#include <iostream>
#include <fstream>
#include <Windows.h>

using namespace std;

struct Data
{
	int number_nodes;
	int** grafpptr;
};

Data read_data(const char*);
void display_data(Data);
void Dijkstra(Data, int);

int main()
{
	int source_node;

	setlocale(LC_ALL, "Russian");

	Data data = read_data("graf.txt");

	cout << "Введите номер исходной вершины от 1 до " << data.number_nodes << ": ";
	cin >> source_node;

	Dijkstra(data, source_node - 1);

	// удаление динамического массива графа
	for (int i = 0; i < data.number_nodes; i++)
		delete[] data.grafpptr[i];

	return 0;
}

Data read_data(const char* filename)
{

	Data d;

	FILE* F;

	fopen_s(&F, filename, "r");

	fscanf_s(F, "%d\n", &d.number_nodes);


	d.grafpptr = new int*[d.number_nodes];
	for (int i = 0; i < d.number_nodes; i++)
		d.grafpptr[i] = new int[d.number_nodes];


	for (int i = 0; i < d.number_nodes; i++)
		for (int j = 0; j < d.number_nodes; j++)
		{
			fscanf_s(F, "%d", &d.grafpptr[i][j]);
		}

	display_data(d);
	return d;
}

void display_data(Data d)
{
	cout << "Отображение заданой матрицы весов" << endl;
	for (int i = 0; i < d.number_nodes; i++)
	{
		for (int j = 0; j < d.number_nodes; j++)
		{
			cout << " " << d.grafpptr[i][j];
		}
		cout << endl;
	}
}

void Dijkstra(Data d, int st)
{
	int* distance = new int[d.number_nodes];
	bool* visited = new bool[d.number_nodes];
	int count, index, i, u, m = st + 1;

	for (i = 0; i < d.number_nodes; i++)
	{
		distance[i] = INT_MAX;
		visited[i] = false;
	}

	distance[st] = 0;
	for (count = 0; count < d.number_nodes - 1; count++)
	{
		int min = INT_MAX;
		for (i = 0; i < d.number_nodes; i++)
			if (!(visited[i]) && ((distance[i]) <= min))
			{
				min = distance[i];
				index = i;
			}
		u = index;
		visited[u] = true;

		for (i = 0; i < d.number_nodes; i++)
			if (!(visited[i]) && (d.grafpptr[u][i]) && (distance[u]) != INT_MAX && (distance[u] + d.grafpptr[u][i] < (distance[i])))
				distance[i] = (distance[u]) + d.grafpptr[u][i];
	}
	cout << "Стоимость пути из начальной вершины до остальных:" << endl;
	for (i = 0; i < d.number_nodes; i++)
	{
		if (distance[i] != INT_MAX)
			cout << m << " > " << i + 1 << " " << distance[i] << endl;
		else
			cout << m << " > " << i + 1 << " = маршрут не доступен" << endl;
	}

	// удаление временных динамических массивов, созданых данной функцией
	delete[] distance;
	delete[] visited;
}