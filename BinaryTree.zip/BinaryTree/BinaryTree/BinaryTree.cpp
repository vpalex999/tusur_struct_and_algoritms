﻿// BinaryTree.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

// BinaryTree.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
//Вариант No 5
//Дана последовательность чисел.Написать программу, которая:
// 1. формирует бинарное дерево
// 2. выводит построенное дерево на экран
// 3. подсчитывает число вершин на n - ом уровне сформированного дерева.
//	  кореньсчитать вершиной 0 - ого уровня.
// 4. После выполнения программы очистить память, занятую древовидной структурой.

#include "pch.h"
#include <iostream>
#include <conio.h>

using namespace std;


struct Node
{
	int data;	// данные
	int count;	// служебное поле
	int* left;	// адрес левый
	int* right;	// адрес правый
};

struct BinaryTree
{
	int Data;			// поле данный
	BinaryTree* Left;	// указатель левого потомка
	BinaryTree* Right;	// указатель правого потомка
};


void Insert_Node_BinaryTree(BinaryTree**, int);	// вставка вершины  бинарное дерево
void Create(BinaryTree**, int);	//создание бинарного дерева
void Vyvod(BinaryTree**, int);	// Вывод двоичного дерева на экран
void Delete_Node_BinaryTree(BinaryTree**, int);	// Удаление вершины бинарного дерева
bool empty_tree(BinaryTree*); //Проверка что дерево не пустое
void PreOrder_BinaryTree(BinaryTree*);	// прямой обход бинарного дерева
int CountNodeLevel(BinaryTree*, int, int = 0); // подсчёт числа вершин на n-ом уровне
BinaryTree* Delete_BinaryTree(BinaryTree*);	// Освобождение памяти бинарного дерева

int main() {
	setlocale(LC_ALL, "Russian");

	int i, n, temp;
	BinaryTree* Root;
	Root = NULL;
	int level;

	cout << "Введите число элементов дерева: "; cin >> n;

	for (i = 0; i < n; i++)
	{
		cout << "Введите данные: "; cin >> temp;
		Create(&Root, temp);
	}

	Vyvod(&Root, 0);


	cout << "\nВведите n-уровень дерева для подсчёта вершин: "; cin >> level;
	int m = CountNodeLevel(Root, level);
	cout << "На " << level << " уровне обнаружено " << m << " узла(ов)." << endl;

	//Освобождение памяти бинарного дерева
	Root = Delete_BinaryTree(Root);
	if (empty_tree(Root))
		cout << "\nПамять очищена!" << endl;

	_getch();

	return 0;
}

//Освобождение памяти бинарного дерева
BinaryTree* Delete_BinaryTree(BinaryTree* Node)
{
	if (Node != NULL)
	{
		Delete_BinaryTree(Node->Left);
		Delete_BinaryTree(Node->Right);
		delete Node;
	}
	return NULL;
}

// подсчёт числа вершин на n-ом уровне
int CountNodeLevel(BinaryTree* Node, int level, int i)
{
	int n = 0;

	if (Node != NULL)
	{
		if (i == level)
		{
			n++;
			//cout << Node->Data;
		}

		if (Node->Left != NULL)
			n += CountNodeLevel(Node->Left, level, i + 1);
		if (Node->Right != NULL)
			n += CountNodeLevel(Node->Right, level, i + 1);
	}

	return n;
}


// прямой обход бинарного дерева
void PreOrder_BinaryTree(BinaryTree* Node)
{
	if (Node != NULL)
	{
		cout << Node->Data << endl;
		PreOrder_BinaryTree(Node->Left);
		PreOrder_BinaryTree(Node->Right);
	}
}

// вставка вершины  бинарное дерево
void Insert_Node_BinaryTree(BinaryTree** Node, int Data)
{
	BinaryTree* New_Node = new BinaryTree;  // выделим место в памяти под структуру
	New_Node->Data = Data;
	New_Node->Left = NULL;
	New_Node->Right = NULL;

	BinaryTree** ptr = Node;

	while (*ptr != NULL)
	{
		if (Data < (*ptr)->Data)
			ptr = &((*ptr)->Left);
		else
		{
			ptr = &((*ptr)->Right);
		}
	}
	*ptr = New_Node;
}

//создание бинарного дерева
void Create(BinaryTree** p, int x)
{
	if (!(*p))	// если указатель равен NULL
	{
		BinaryTree* pnew = new BinaryTree;  // выделим место в памяти под структуру
		pnew->Data = x;
		pnew->Left = NULL;
		pnew->Right = NULL;
		*p = pnew;
	}
	else
	{
		if ((*p)->Data > x)
			Create(&((*p)->Left), x);
		else
			Create(&((*p)->Right), x);
	}
}

// Вывод двоичного дерева на экран
void Vyvod(BinaryTree** p, int l)
{
	int i;
	if (*p != NULL)
	{
		Vyvod(&((*p)->Right), l + 1);
		for (i = 0; i < l; i++)
		{
			cout << "   ";
		}
		cout << (*p)->Data << endl;
		Vyvod(&((*p)->Left), l + 1);
	}
}

// Удаление вершины бинарного дерева
void Delete_Node_BinaryTree(BinaryTree** Node, int Data)
{
	if ((*Node) != NULL)
	{
		if ((*Node)->Data == Data)
		{
			BinaryTree* ptr = (*Node);
			if ((*Node)->Left == NULL && (*Node)->Right == NULL)
				(*Node) = NULL;
			else if ((*Node)->Left == NULL)
				(*Node) = ptr->Right;
			else if ((*Node)->Right == NULL)
				(*Node) = ptr->Left;
			else
			{
				(*Node) = ptr->Right;
				BinaryTree** ptr1;
				ptr1 = Node;
				while (*ptr1 != NULL)
					ptr1 = &((*ptr1)->Left);
				(*ptr1) = ptr->Left;
			}
			delete ptr;
			Delete_Node_BinaryTree(Node, Data);
		}
		else
		{
			Delete_Node_BinaryTree(&((*Node)->Left), Data);
			Delete_Node_BinaryTree(&((*Node)->Right), Data);
		}
	}
}

// проверка, что дерево не пустое
bool empty_tree(BinaryTree* Node)
{
	if (Node == NULL)
	{
		cout << "\nДерево пусто!" << endl;
		return true;
	}
	else
		return false;
}
